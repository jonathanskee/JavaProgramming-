
/**
 * This class launches the Mastermind game.
 * @author Jonathan Skee
 *
 */
public class LauncherSkeeJonathan {
	//This calls the gameLoop method
	public static void main(String[] args) {
		Mastermind m = new Mastermind();
		m.gameLoop();
	}
}
