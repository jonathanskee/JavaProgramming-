import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * This class contains the methods for playing Mastermind
 * @author Jonathan Skee
 *
 */
public class Mastermind {
	//This is the AI's color sequence
	private ArrayList<Character> secret;
	
	/**
	 * This generates random number for the AI's color sequence
	 */
	public Mastermind() {
		secret = new ArrayList<Character>();
		Random rand = new Random();
		//This generates random numbers and assigns them to a letter
		for (int i = 0; i < 4; i++) {
			int next = rand.nextInt(5);
			if (next == 0) {
				secret.add('R');
			}
			else if (next == 1) {
				secret.add('Y');
			}
			else if (next == 2) {
				secret.add('B');
			}
			else if (next == 3) {
				secret.add('G');
			}
			else if (next == 4) {
				secret.add('P');
			}
		}
	}
	
	/**
	 * This makes sure the guess is the right length and characters
	 * @param guess
	 * @return true/false
	 */
	public boolean isGoodGuess(ArrayList<Character>guess) {
		//Checks to verify size
		if (guess.size() != secret.size()) {
			return false;
		}
		//Checks to verify right letters
		else {
			for (int i = 0; i < guess.size(); i++) {
				char C = guess.get(i);
				if ((C != 'R') && (C != 'Y') && (C != 'B') && (C != 'G') && (C != 'P')) {
					return false;
					
				}
			}
		}
		return true;
	}
	
	/**
	 * This calls the other methods and runs the game
	 */
	public void gameLoop() {
		Scanner scn = new Scanner(System.in);
		scn.useDelimiter("");
		ArrayList<Character> guess = new ArrayList<Character>();
		//Counter counts number of guesses
		int counter = 0;
		//Loop runs until the game is won
		while (true) {
			//Loop runs until a good guess is given
			while (true) {
				guess.clear();
				System.out.println("Please provide a guess (all caps).");
				//Takes in character guesses
				while (scn.hasNext()) {
					char C = scn.next().charAt(0);
					if (C == '\n') {
						break;
					}
					guess.add(C);
				}
				guess.remove(guess.size() - 1);
				System.out.println(guess);
				//Verifies if it's a good guess
				if (isGoodGuess (guess)) {
					break;
				}
			}
			//Checks how many right color/right position && right color/wrong position
			int halfRightNum = numHalfRight(guess);
			int allRightNum = numAllRight(guess);
			
			System.out.println(allRightNum + " right color/right position. " + halfRightNum + " right color, wrong position");
			counter++;
			System.out.println("Number of guesses: " + counter);
		}
	}
	
	/**
	 * This checks how many guesses match color and position
	 * @param guess
	 * @return tally
	 */
	public int numAllRight(ArrayList<Character> guess) {
		int tally = 0;
		//Counts number of right color and position
		for (int i = 0; i < 4; i++) {
			if (secret.get(i) == guess.get(i)) {
				tally++;
			}
		}
		return tally;
	}
	
	/**
	 * This counts the number of guesses which are the right color
	 * @param guess
	 * @return final
	 */
	public int numHalfRight(ArrayList<Character> guess) {
		//New arry lists preserve old ones
		ArrayList<Character> secretcopy = new ArrayList<Character>(secret);
		ArrayList<Character> guesscopy = new ArrayList<Character>(guess);
		
		//Takes out right color and position matches
		for (int i = 0; i < secretcopy.size(); i++) {
			if (secretcopy.get(i) == guesscopy.get(i)) {
				secretcopy.remove(i);
				guesscopy.remove(i);
				i--;
			}
		}
		
		//Counts number of reds are shared
		int guessReds = 0;
		int secretReds = 0;
		for (int i = 0; i < guesscopy.size(); i++) {
			if (guesscopy.get(i) == 'R') {
				guessReds++;
			}
			if (secretcopy.get(i) == 'R') {
				secretReds++;
			}
		}
		int finalRed = Math.min(secretReds, guessReds);
		
		//Counts number of yellows are shared
		int guessYellows = 0;
		int secretYellows = 0;
		for (int i = 0; i < guesscopy.size(); i++) {
			if (guesscopy.get(i) == 'Y') {
				guessYellows++;
			}
			if (secretcopy.get(i) == 'Y') {
				secretYellows++;
			}
		}
		int finalYellow = Math.min(secretYellows, guessYellows);
		
		//Counts number of blues are shared
		int guessBlues = 0;
		int secretBlues = 0;
		for (int i = 0; i < guesscopy.size(); i++) {
			if (guesscopy.get(i) == 'B') {
				guessBlues++;
			}
			if (secretcopy.get(i) == 'B') {
				secretBlues++;
			}
		}
		int finalBlue = Math.min(secretBlues, guessBlues);
		
		//Counts number of greens are shared
		int guessGreens = 0;
		int secretGreens = 0;
		for (int i = 0; i < guesscopy.size(); i++) {
			if (guesscopy.get(i) == 'G') {
				guessGreens++;
			}
			if (secretcopy.get(i) == 'G') {
				secretGreens++;
			}
		}
		int finalGreen = Math.min(secretGreens, guessGreens);
		
		//Counts number of purples are shared
		int guessPurples = 0;
		int secretPurples = 0;
		for (int i = 0; i < guesscopy.size(); i++) {
			if (guesscopy.get(i) == 'P') {
				guessPurples++;
			}
			if (secretcopy.get(i) == 'P') {
				secretPurples++;
			}
		}
		int finalPurple = Math.min(secretPurples, guessPurples);
		
		return finalRed + finalYellow + finalBlue + finalGreen + finalPurple;
	}
}


