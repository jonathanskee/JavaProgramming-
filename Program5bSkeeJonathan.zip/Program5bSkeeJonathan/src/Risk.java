import java.util.Random;

/**
 * This class contains a method for organizing a Risk combat situation and deciding who wins.
 * @author Jonathan Skee
 *
 */
public class Risk {
	//These are private variables used to define each army's size
	private int attackerStrength;
	private int defenderStrength;
	
	/**
	 * This is a constructor for Risk.
	 * @param aStrength Size of attacking army.
	 * @param dStrength Size of defending army.
	 */
	public Risk(int aStrength, int dStrength) {
		this.attackerStrength = aStrength;
		this.defenderStrength = dStrength;
	}
	
	/**
	 * This method generates a random dice roll.
	 * @return Die amount.
	 */
	public int roll() {
		Random rand = new Random();
		//This sets the range from 1-6
		return rand.nextInt(6) + 1;
	}
	
	/** 
	 * This method takes arrays of length 2 or 3 and sorts them in decreasing order.
	 * @param array The length of the array.
	 * @return The array sorted in decreasing order.
	 */
	public void sortRolls(int[] array) {
    	//This makes sure the arrays are length 2 or 3
		if ((array.length != 2) && (array.length != 3)) {
			return;
		}
		//This sorts the array in decreasing order if length 2
		else {
			if (array.length == 2) {
				if (array[0] < array[1]) {
					int temp = array[0];
					array[0] = array[1];
					array[1] = temp;
				}
			}
			//This sorts the array in decreasing order if length 3
			else if (array.length == 3) {
				if (array[1] < array[2]) {
					int temp2 = array[2];
					array[2] = array[1];
					array[1] = temp2;
				}
				if (array[0] < array[1]) {
					int temp3 = array[0];
					array[0] = array[1];
					array[1] = temp3;
				}
				if (array[1] < array[2]) {
					int temp = array[1];
					array[1] = array[2];
					array[2] = temp;
				}
			}
		}
	}
    
    /**
     * This method checks to see if the attacker wins or loses.
     * @param attackRoll Roll of the attacker's die.
     * @param defendRoll Roll of the defender's die.
     * @return True/false.
     */
	public boolean attackerLoses(int attackRoll, int defendRoll) {
    	//Defender wins ties and when it's larger than attacker's roll
		return (attackRoll <= defendRoll);
    }
		
	/**
	 * This method creates two arrays, sorts them, checks to see who won, notes how many each lost, and subtracts from each side's strength accordingly.
	 */
    public void riskRoll() {
    	//This section sets up the attacker's array and defender's array, setting a range of 1-3 and 1-2, respectively
    	int min = Math.min(3, (attackerStrength - 1));
    	int min2 = Math.min(2, defenderStrength);
    	int[] attackArray = new int[Math.max(min, 1)];
    		for (int i = 0; i < attackArray.length; i++) {
    			attackArray[i] = roll();
    		}
    	int[] defenseArray = new int[Math.max(min2, 1)];
    		for (int i = 0; i < defenseArray.length; i++) {
    			defenseArray[i] = roll();
    		}
    		
    	//This sorts the rolls from biggest to smallest in each array
    	sortRolls(attackArray);
    	sortRolls(defenseArray);
    	
    	//smallerArray makes sure the for loop iterates only as many times as the number of applicable dice pairs present
    	int smallerArray = Math.min(attackArray.length, defenseArray.length);
    	int attackerLost = 0;
    	int defenderLost = 0;
    	
    	//This loop iterates for each dice pair
    	for (int i = 0; i < smallerArray; i++) {
    		//If attacker loses, the attacker loses 1 strength and gains 1 loss
    		if (attackerLoses(attackArray[i], defenseArray[i])) {
    			//If less than 2, he loses
    			if (attackerStrength < 2) {
    				break;
    			}
    			attackerStrength--;
    			attackerLost++;
    		}
    		//Otherwise, the defender loses 1 strength and gains 1 loss
    		else {
    			//If less than 1, they can't defend anymore
    			if (defenderStrength < 1) {
    				break;
    			}
    			defenderStrength--;
    			defenderLost++;
    		}
    	}
    	
    	//This prints the rolls of the attacker
    	System.out.print("The attacker rolled these outcomes: ");
    	for (int i = 0; i < attackArray.length; i++) {
    		System.out.print(attackArray[i] + " ");
    	}
    	System.out.println();
    	
    	//This prints the rolls of the defender
    	System.out.print("The defender rolled these outcomes: ");
    	for (int i = 0; i < defenseArray.length; i++) {
    		System.out.print(defenseArray[i] + " ");
    	}
    	System.out.println();
    	
    	//Each of these print attacker/defender losses and remaining strength for each side
    	System.out.println("The attacker lost this amount of strength: " + attackerLost);
    	System.out.println("The defender lost this amount of strength: " + defenderLost);
    	System.out.println("The attacker has this remaining strength: " + attackerStrength);
    	System.out.println("The defender has this remaining strength: " + defenderStrength);
    }
    
    /**
     * This method plays riskRoll over until a winner is produced.
     */
    public void match() {
    	//Loop continues until someone loses
    	while (true) {
    		
    		//Calls riskRoll
    		riskRoll();
    		
    		//If the attacker gets to 1, he loses
    		if (attackerStrength == 1) {
    			System.out.println("Defender wins!");
    			break;
    		}
    		
    		//If the defender gets to 0, he can't defend anymore
    		else if (defenderStrength == 0) {
    			System.out.println("Attacker wins!");
    			break;
    		}
    	}
    }
}
