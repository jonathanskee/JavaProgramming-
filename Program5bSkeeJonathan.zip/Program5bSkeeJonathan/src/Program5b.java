import java.util.Scanner;

/**
 * This class plays out a full Risk war.
 * @author SKEEJD17
 *
 */
public class Program5b {
	/** 
	 * Main plays out the war.
	 */
	public static void main(String[] args) {
		//a and b are the strengths of the attacker and defender, respectively
		int a = 0;
		int b = 0;
		Scanner scnr = new Scanner(System.in);
		
		//Asks for attacker's strength
		System.out.println("Please provide the attacker's strength");
		a = scnr.nextInt();
		//If less than 1, it asks again
		while (a < 1) {
			System.out.println("Error, please provide a number above 0.");
			a = scnr.nextInt();
		}
		
		//Asks for defender's strength
		System.out.println("Please provide the defender's strength");
		b = scnr.nextInt();
		//If less than 1, it asks again
		while (b < 1) {
			System.out.println("Error, please provide a number above 0.");
			b = scnr.nextInt();
		}
		
		//Closes scanner
		scnr.close();
		
		//This is a Risk object
		Risk gameOn = new Risk(a, b);
		
		//This puts gameOn thru the match() method to see who wins
		gameOn.match();
	}
}
