/**
 * This class contains the Vehicle code.
 * @author Jonathan Skee
 *
 */
public class Vehicle {
	protected int price;
	protected String model;
	
	/**
	 * toString returns Vehicle info.
	 */
	public String toString() {
		return "Price: $" + price + ". Model: " + model + ".";
	}
}