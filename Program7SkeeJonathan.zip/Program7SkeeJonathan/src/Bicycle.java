/**
 * This class contains the Bicycle code.
 * @author Jonathan Skee
 *
 */
public class Bicycle extends Vehicle {
	
	/**
	 * Constructor returns Bicycle info.
	 * @param model
	 * @param price
	 */
	public Bicycle(String model, int price) {
		this.price = price;
		this.model = model;
	}
	
	/**
	 * toString returns Bicycle and links to Vehicle toString.
	 */
	@Override
	public String toString() {
		return "Bicycle - " + super.toString();
	}
}