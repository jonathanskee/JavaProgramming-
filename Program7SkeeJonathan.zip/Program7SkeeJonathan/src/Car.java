/**
 * This class contains the Car code.
 * @author Jonathan Skee
 *
 */
public class Car extends Vehicle {
	private int mileage;
	
	/**
	 * Constructor constructs price, model, and mileage.
	 * @param model
	 * @param price
	 * @param mileage
	 */
	public Car(String model, int price, int mileage) {
		this.price = price;
		this.model = model;
		this.mileage = mileage;
	}
	
	/**
	 * Returns car and mileage and links to Vehicle toString.
	 */
	@Override
	public String toString( ) {
		return "Car - Mileage: " +  mileage + ", " + super.toString();
	}
}
