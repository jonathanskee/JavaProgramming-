import java.io.IOException;

/**
 * This class runs the program.
 * @author Jonathan Skee
 *
 */
public class LotManager {
	/**
	 * Main loops the getInput method.
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		Inventory i = new Inventory();
		//Loops getInput
		while (true) {
			//Tests inputs
			try {
				i.getInput();
			}
			//Catches exceptions and outputs appropriate error message
			catch(Exception f) {
				System.out.println("Something went wrong.");
				System.out.println(f.getMessage());
			}
		}
	}
}
