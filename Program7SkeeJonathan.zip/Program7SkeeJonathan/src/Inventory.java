import java.util.ArrayList;
import java.io.IOException;
import java.util.Scanner;

/**
 * This class contains the inventory management.
 * @author Jonathan Skee
 *
 */
public class Inventory {
	public int balance = 100000;
	ArrayList<Vehicle> vehicles = new ArrayList<Vehicle>();
	Scanner scn = new Scanner(System.in);
	
	/**
	 * Links the toString and delivers output of inventory.
	 */
	public String toString() {
		return "Vehicles: " + vehicles.toString();
	}
	
	/**
	 * This allows the user to print inventory, buy, or sell a vehicle.
	 * @throws Exception
	 */
	public void getInput() throws Exception {
		System.out.println("Current balance: $" + balance);
		System.out.println("Would you like to 1. Print inventory, 2. Buy a vehicle, or 3. Sell a vehicle? Please type 1, 2, or 3 to indicate your choice.");
		//Catches non-integer answers and throws
		if (scn.hasNext() && !scn.hasNextInt()) {
			scn.next();
			throw new Exception("Non-integer answer.");
		}
		int choice = scn.nextInt();
		//Catches answers that are too big or small and throws 
		if ((choice > 3) || (choice < 1)) {
			throw new Exception("Non-valid answer.");
		}
		
		//Prints current inventory
		if (choice == 1) {
			System.out.println(toString());
		}
		
		//Allows one to buy a bicycle or car
		if (choice == 2) {
			System.out.println("Would you like to 1. Buy a bicycle, or 2. Buy a car?");
			//Catches non-integer answers and throws
			if (scn.hasNext() && !scn.hasNextInt()) {
				scn.next();
				throw new Exception("Non-integer answer.");
			}
			int selection = scn.nextInt();
			//Catches answers which are too big or small and throws
			if ((selection > 2) || (selection < 1)) {
				throw new Exception("Non-valid answer.");
			}
			
			//Purchases a bicycle
			if (selection == 1) {
				System.out.println("Enter the model you want.");
					String mod = scn.next();
				System.out.println("Enter the price.");
					//Catches non-integer answers and throws
					if (scn.hasNext() && !scn.hasNextInt()) {
						scn.next();
						throw new Exception("Non-integer answer.");
					}
					int pric = scn.nextInt();
					//Catches negative prices and throws
					if (pric < 0) {
						throw new Exception("Non-valid answer.");
					}
				//Tests for valid balance
				if (balance < pric) {
					throw new Exception("Not enough money");
				}
				//Adjusts balance
				balance = balance - pric;
				//Adds vehicle to inventory
				Bicycle b = new Bicycle(mod, pric);
				vehicles.add(b);
				System.out.println("Purchase successful.");
			}
			
			//Purchases car
			if (selection == 2) {
				System.out.println("Enter the model you want.");
				String mod = scn.next();
			System.out.println("Enter the price.");
				//Catches non-integer answers and throws
				if (scn.hasNext() && !scn.hasNextInt()) {
					scn.next();
					throw new Exception("Non-integer answer.");
				}
				int pri = scn.nextInt();
				//Catches negative prices and throws
				if (pri < 0) {
					throw new Exception("Non-valid answer.");
				}
			System.out.println("Enter the mileage.");
				//Catches non-integer answers and throws
				if (scn.hasNext() && !scn.hasNextInt()) {
					scn.next();
					throw new Exception("Non-integer answer.");
				}
				int mile = scn.nextInt();
				//Catches negative mileage answers and throws
				if (mile < 0) {
					throw new Exception("Non-valid answer.");
				}
			//Tests for valid balance
			if (balance < pri) {
				throw new Exception("Not enough money");
			}
			//Adjusts balance
			balance = balance - pri;
			//Updates inventory
			Car c = new Car(mod, pri, mile);
			vehicles.add(c);
			System.out.println("Purchase successful.");
			}
		}	
		
		//Sells vehicles
		if (choice == 3) {
			System.out.println("Type the number of the vehicle you are selling.");
				//Catches non-integer answers and throws
				if (scn.hasNext() && !scn.hasNextInt()) {
					scn.next();
					throw new Exception("Non-integer answer.");
				}
				int selection2 = scn.nextInt();
				//Catches answers that aren't in the ArrayList and throws
				if (selection2 < 0 || selection2 > (vehicles.size() + 1)) {
					throw new Exception("Non-valid answer.");
				}
				//Removes vehicle
				vehicles.remove(selection2);
			System.out.println("Enter the price you're selling for.");
				//Catches non-integer answers and throws
				if (scn.hasNext() && !scn.hasNextInt()) {
					scn.next();
					throw new Exception("Non-integer answer.");
				}
				int pri2 = scn.nextInt();
				//Catches negative price answers and throws
				if (pri2 < 0) {
					throw new Exception("Non-valid answer.");
				}
			//Updates balance
			balance = balance + pri2;
			System.out.println("Sale successful.");
		}		
	}
}